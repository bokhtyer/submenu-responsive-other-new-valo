(function($){
	'use script';

	// WOW JS
	new WOW().init();

	// Menu Responsive
	// $(document).ready(function(){
	// 	$('.mobile-menu').click(function(){
	// 		$('.menu ul').slideToggle();
	// 	});
	// });

	// Scroll Area
	$(document).ready(function(){
	    $('.scroll-area').click(function(){
	      	$('html').animate({
	        	'scrollTop' : 0,
	      	},700);
	      	return false;
	    });
	    $(window).on('scroll',function(){
	      	var a = $(window).scrollTop();
	      	if(a>400){
	            $('.scroll-area').slideDown(300);
	        }else{
	            $('.scroll-area').slideUp(200);
	        }
	    });
	});

/*---canvas menu activation---*/
    $('.canvas_open').on('click', function(){
        $('.offcanvas_menu_wrapper,.off_canvars_overlay').addClass('active')
    });
    
    $('.canvas_close,.off_canvars_overlay').on('click', function(){
        $('.offcanvas_menu_wrapper,.off_canvars_overlay').removeClass('active')
    });


	/*---Off Canvas Menu---*/
    var $offcanvasNav = $('.offcanvas_main_menu'),
        $offcanvasNavSubMenu = $offcanvasNav.find('.sub-menu');
    $offcanvasNavSubMenu.parent().prepend('<span class="menu-expand"><i class="fa fa-angle-down"></i></span>');
    
    $offcanvasNavSubMenu.slideUp();
    
    $offcanvasNav.on('click', 'li a, li .menu-expand', function(e) {
        var $this = $(this);
        if ( ($this.parent().attr('class').match(/\b(menu-item-has-children|has-children|has-sub-menu)\b/)) && ($this.attr('href') === '#' || $this.hasClass('menu-expand')) ) {
            e.preventDefault();
            if ($this.siblings('ul:visible').length){
                $this.siblings('ul').slideUp('slow');
            }else {
                $this.closest('li').siblings('li').find('ul:visible').slideUp('slow');
                $this.siblings('ul').slideDown('slow');
            }
        }
        if( $this.is('a') || $this.is('span') || $this.attr('clas').match(/\b(menu-expand)\b/) ){
        	$this.parent().toggleClass('menu-open');
        }else if( $this.is('li') && $this.attr('class').match(/\b('menu-item-has-children')\b/) ){
        	$this.toggleClass('menu-open');
        }
    });







/*---canvas menu activation---*/
    $('.canvas_open1').on('click', function(){
        $('.offcanvas_menu_wrapper1,.off_canvars_overlay').addClass('active')
    });
    
    $('.canvas_close1,.off_canvars_overlay').on('click', function(){
        $('.offcanvas_menu_wrapper1,.off_canvars_overlay').removeClass('active')
    });


	/*---Off Canvas Menu---*/
    var $offcanvasNav = $('.offcanvas_main_menu1'),
        $offcanvasNavSubMenu = $offcanvasNav.find('.sub-menu1');
    $offcanvasNavSubMenu.parent().prepend('<span class="menu-expand"><i class="fa fa-angle-down"></i></span>');
    
    $offcanvasNavSubMenu.slideUp();
    
    $offcanvasNav.on('click', 'li a, li .menu-expand', function(e) {
        var $this = $(this);
        if ( ($this.parent().attr('class').match(/\b(menu-item-has-children1|has-children|has-sub-menu)\b/)) && ($this.attr('href') === '#' || $this.hasClass('menu-expand')) ) {
            e.preventDefault();
            if ($this.siblings('ul:visible').length){
                $this.siblings('ul').slideUp('slow');
            }else {
                $this.closest('li').siblings('li').find('ul:visible').slideUp('slow');
                $this.siblings('ul').slideDown('slow');
            }
        }
        if( $this.is('a') || $this.is('span') || $this.attr('clas').match(/\b(menu-expand)\b/) ){
        	$this.parent().toggleClass('menu-open');
        }else if( $this.is('li') && $this.attr('class').match(/\b('menu-item-has-children1')\b/) ){
        	$this.toggleClass('menu-open');
        }
    });











	// var mixer = mixitup('.portfolio-item-full');
	// var mixer = mixitup('.portF');
	// var mixer = mixitup('.portF', {
	// 	selectors: {
	// 		target: '.blog-item'
	// 	},
	// 	animation: {
	// 		duration: 100
	// 	}
	// });


	// $('.portfolio-single a').magnificPopup({
	//   	type: 'image',
	//    	gallery: {
	//     	enabled: true
	//   	},
	  	
	// });

	// $(document).ready(function(){
	//   	$(".our-client-full").owlCarousel({
	//   		loop:true,
	//   		center:true,
	//   		items:1,
	//   		autoplay: true,
	//   	});
	// });



	// Sticky Menu
	// $(document).ready(function(){
	// 	$(window).on('scroll',function(){
	// 		var scroll = $(window).scrollTop();
	// 		if(scroll < 150){
	// 			$('.header_top').removeClass('sticky');
	// 		}else{
	// 			$('.header_top').addClass('sticky');
	// 		}
	// 	});
	// });


	

	// $(document).ready(function(){
	// 	let mainNavLinks = document.querySelectorAll(".menu ul li a");
	// 	let mainSections = document.querySelectorAll("main section");

	// 	let lastId;
	// 	let cur = [];

		
	// 	window.addEventListener("scroll", event => { 
	// 	  let fromTop = window.scrollY;

	// 	  	mainNavLinks.forEach(link => {
	// 	    let section = document.querySelector(link.hash);

	// 	   	if (
	// 	      section.offsetTop <= fromTop &&
	// 	      section.offsetTop + section.offsetHeight > fromTop
	// 	    ) {
	// 	      link.classList.add("current");
	// 	    } else {
	// 	      link.classList.remove("current");
	// 	    }
	// 	  	});
	// 	});
	// });


	// $('#nav').onePageNav({
	// 		currentClass: 'current',
	// 		changeHash: false,
	// 		scrollSpeed: 750,
	// 		scrollThreshold: 0.5,
	// 		filter: '',
	// 		easing: 'swing',
	// 		begin: function() {
	// 			//I get fired when the animation is starting
	// 		},
	// 		end: function() {
	// 			//I get fired when the animation is ending
	// 		},
	// 		scrollChange: function($currentListItem) {
	// 			//I get fired when you enter a section and I pass the list item of the section
	// 		}
	// 	});



}(jQuery));